##### Bug Report or Feature Request (mark with an `x`)
```
- [ ] Regression (a behavior that used to work and stopped working in a new release)
- [ ] Bug report -> please search issues before submitting
- [ ] Feature request
- [ ] Documentation issue or request
```
